create function nanoid_optimized(size integer, alphabet text, mask integer, step integer) returns text
    parallel safe
    language plpgsql
as
$$
DECLARE
    idBuilder      text := '';
    counter        int  := 0;
    bytes          bytea;
    alphabetIndex  int;
    alphabetArray  text[];
    alphabetLength int  := 64;
BEGIN
    alphabetArray := regexp_split_to_array(alphabet, '');
    alphabetLength := array_length(alphabetArray, 1);

    LOOP
        bytes := gen_random_bytes(step);
        FOR counter IN 0..step - 1
            LOOP
                alphabetIndex := (get_byte(bytes, counter) & mask) + 1;
                IF alphabetIndex <= alphabetLength THEN
                    idBuilder := idBuilder || alphabetArray[alphabetIndex];
                    IF length(idBuilder) = size THEN
                        RETURN idBuilder;
                    END IF;
                END IF;
            END LOOP;
    END LOOP;
END
$$;

alter function nanoid_optimized(integer, text, integer, integer) owner to postgres;

grant execute on function nanoid_optimized(integer, text, integer, integer) to anon;

grant execute on function nanoid_optimized(integer, text, integer, integer) to authenticated;

grant execute on function nanoid_optimized(integer, text, integer, integer) to service_role;

