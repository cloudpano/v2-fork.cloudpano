create function public_id() returns text
    language plpgsql
as
$$
BEGIN
    RETURN nanoid(10, '23456789abcdefghijklmnopqrstuvwxyz', 1.85);
END;
$$;

alter function public_id() owner to postgres;

grant execute on function public_id() to anon;

grant execute on function public_id() to authenticated;

grant execute on function public_id() to service_role;

